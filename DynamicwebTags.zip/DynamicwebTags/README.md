# netsi1964Test

Don't expect anything here :-) 
I am testing my first Brackets Extension


[My inspiration](http://code.tutsplus.com/tutorials/creating-brackets-extensions--net-36781)